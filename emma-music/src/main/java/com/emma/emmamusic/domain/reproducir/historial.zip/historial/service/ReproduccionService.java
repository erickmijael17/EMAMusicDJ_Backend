package com.emma.emmamusic.domain.reproducir.historial.service;

import com.emma.emmamusic.domain.reproducir.historial.dto.ReproduccionDTO;

import java.time.Instant;
import java.util.List;

public interface ReproduccionService {

    ReproduccionDTO registrarReproduccion(Long usuarioId, String videoId);

    List<ReproduccionDTO> obtenerHistorialPorUsuario(Long usuarioId);

    List<ReproduccionDTO> obtenerHistorialPorUsuarioYRango(Long usuarioId, Instant fechaInicio, Instant fechaFin);

    List<ReproduccionDTO> obtenerHistorialPorVideoId(String videoId);

    long contarReproduccionesPorUsuario(Long usuarioId);

    long contarReproduccionesPorVideoId(String videoId);

    List<ReproduccionDTO> obtenerMasReproducidas(int limit);

    void eliminarHistorialUsuario(Long usuarioId);
}

