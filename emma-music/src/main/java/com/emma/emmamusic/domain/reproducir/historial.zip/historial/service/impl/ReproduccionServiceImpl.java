package com.emma.emmamusic.domain.reproducir.historial.service.impl;

import com.emma.emmamusic.domain.auth.model.Usuario;
import com.emma.emmamusic.domain.auth.repository.UsuarioRepository;
import com.emma.emmamusic.domain.buscar.model.MetadatoYoutube;
import com.emma.emmamusic.domain.buscar.repository.MetadatoYoutubeRepository;
import com.emma.emmamusic.domain.reproducir.historial.dto.ReproduccionDTO;
import com.emma.emmamusic.domain.reproducir.historial.mapper.ReproduccionMapper;
import com.emma.emmamusic.domain.reproducir.historial.model.Reproduccion;
import com.emma.emmamusic.domain.reproducir.historial.repository.ReproduccionRepository;
import com.emma.emmamusic.domain.reproducir.historial.service.ReproduccionService;
import com.emma.emmamusic.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ReproduccionServiceImpl implements ReproduccionService {

    private final ReproduccionRepository reproduccionRepository;
    private final MetadatoYoutubeRepository metadatoYoutubeRepository;
    private final UsuarioRepository usuarioRepository;
    private final ReproduccionMapper mapper;

    @Override
    @Transactional
    public ReproduccionDTO registrarReproduccion(Long usuarioId, String videoId) {
        log.info("Registrando reproducción: usuario={}, videoId={}", usuarioId, videoId);

        Usuario usuario = usuarioRepository.findById(usuarioId)
                .orElseThrow(() -> new ResourceNotFoundException("Usuario", "id", usuarioId));

        MetadatoYoutube metadato = metadatoYoutubeRepository.findByIdVideoYoutube(videoId)
                .orElseThrow(() -> new ResourceNotFoundException("Metadato", "videoId", videoId));

        Reproduccion reproduccion = Reproduccion.builder()
                .usuario(usuario)
                .metadatoYoutube(metadato)
                .idVideoYoutube(videoId)
                .build();

        reproduccionRepository.save(reproduccion);

        metadato.setContadorReproducciones(metadato.getContadorReproducciones() + 1);
        metadato.setUltimaActividad(Instant.now());
        metadatoYoutubeRepository.save(metadato);

        log.info("Reproducción registrada exitosamente");
        return mapper.toDTO(reproduccion);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ReproduccionDTO> obtenerHistorialPorUsuario(Long usuarioId) {
        log.info("Obteniendo historial para usuario: {}", usuarioId);

        List<Reproduccion> reproducciones = reproduccionRepository.findByUsuarioId(usuarioId);

        return reproducciones.stream()
                .map(mapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ReproduccionDTO> obtenerHistorialPorUsuarioYRango(Long usuarioId, Instant fechaInicio, Instant fechaFin) {
        log.info("Obteniendo historial para usuario {} entre {} y {}", usuarioId, fechaInicio, fechaFin);

        List<Reproduccion> reproducciones = reproduccionRepository.findByUsuarioIdAndFechaRange(
                usuarioId, fechaInicio, fechaFin);

        return reproducciones.stream()
                .map(mapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ReproduccionDTO> obtenerHistorialPorVideoId(String videoId) {
        log.info("Obteniendo historial para videoId: {}", videoId);

        List<Reproduccion> reproducciones = reproduccionRepository.findByVideoId(videoId);

        return reproducciones.stream()
                .map(mapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public long contarReproduccionesPorUsuario(Long usuarioId) {
        return reproduccionRepository.countByUsuarioId(usuarioId);
    }

    @Override
    @Transactional(readOnly = true)
    public long contarReproduccionesPorVideoId(String videoId) {
        return reproduccionRepository.countByVideoId(videoId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ReproduccionDTO> obtenerMasReproducidas(int limit) {
        log.info("Obteniendo {} canciones más reproducidas", limit);

        List<Object[]> results = reproduccionRepository.findMostPlayedTracks();

        return results.stream()
                .limit(limit)
                .flatMap(result -> {
                    Long metadatoId = (Long) result[0];
                    return reproduccionRepository.findByMetadatoId(metadatoId).stream()
                            .findFirst()
                            .map(mapper::toDTO)
                            .stream();
                })
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public void eliminarHistorialUsuario(Long usuarioId) {
        log.info("Eliminando historial para usuario: {}", usuarioId);

        List<Reproduccion> reproducciones = reproduccionRepository.findByUsuarioId(usuarioId);
        reproduccionRepository.deleteAll(reproducciones);

        log.info("Historial eliminado: {} registros", reproducciones.size());
    }
}

