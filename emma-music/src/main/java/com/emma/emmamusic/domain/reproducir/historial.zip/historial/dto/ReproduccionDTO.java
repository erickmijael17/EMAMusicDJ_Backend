package com.emma.emmamusic.domain.reproducir.historial.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.Instant;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReproduccionDTO {

    private Long id;
    private Long usuarioId;
    private Long metadatoId;
    private String idVideoYoutube;
    private String titulo;
    private String canal;
    private Integer duracionSegundos;
    private String miniaturaUrl;
    private Instant fechaReproduccion;
    private Integer duracionReproducidaSegundos;
    private BigDecimal porcentajeCompletado;
    private String tipoDispositivo;
    private String direccionIp;
    private String pais;
    private String ciudad;
}

