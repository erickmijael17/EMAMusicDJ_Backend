package com.emma.emmamusic.domain.reproducir.historial.repository;

import com.emma.emmamusic.domain.reproducir.historial.model.Reproduccion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;

@Repository
public interface ReproduccionRepository extends JpaRepository<Reproduccion, Long> {

    @Query("SELECT r FROM Reproduccion r WHERE r.usuario.usuarioId = :usuarioId ORDER BY r.fechaReproduccion DESC")
    List<Reproduccion> findByUsuarioId(@Param("usuarioId") Long usuarioId);

    @Query("SELECT r FROM Reproduccion r WHERE r.metadatoYoutube.metadatoId = :metadatoId ORDER BY r.fechaReproduccion DESC")
    List<Reproduccion> findByMetadatoId(@Param("metadatoId") Long metadatoId);

    @Query("SELECT r FROM Reproduccion r WHERE r.idVideoYoutube = :videoId ORDER BY r.fechaReproduccion DESC")
    List<Reproduccion> findByVideoId(@Param("videoId") String videoId);

    @Query("SELECT r FROM Reproduccion r WHERE r.usuario.usuarioId = :usuarioId AND r.fechaReproduccion BETWEEN :fechaInicio AND :fechaFin ORDER BY r.fechaReproduccion DESC")
    List<Reproduccion> findByUsuarioIdAndFechaRange(@Param("usuarioId") Long usuarioId, 
                                                   @Param("fechaInicio") Instant fechaInicio, 
                                                   @Param("fechaFin") Instant fechaFin);

    @Query("SELECT COUNT(r) FROM Reproduccion r WHERE r.usuario.usuarioId = :usuarioId")
    long countByUsuarioId(@Param("usuarioId") Long usuarioId);

    @Query("SELECT COUNT(r) FROM Reproduccion r WHERE r.metadatoYoutube.metadatoId = :metadatoId")
    long countByMetadatoId(@Param("metadatoId") Long metadatoId);

    @Query("SELECT COUNT(r) FROM Reproduccion r WHERE r.idVideoYoutube = :videoId")
    long countByVideoId(@Param("videoId") String videoId);

    @Query("SELECT r FROM Reproduccion r WHERE r.usuario.usuarioId = :usuarioId ORDER BY r.fechaReproduccion DESC")
    List<Reproduccion> findRecentByUsuarioId(@Param("usuarioId") Long usuarioId);

    @Query("SELECT r.metadatoYoutube.metadatoId, COUNT(r) as reproductions FROM Reproduccion r GROUP BY r.metadatoYoutube.metadatoId ORDER BY reproductions DESC")
    List<Object[]> findMostPlayedTracks();

    @Query("SELECT r FROM Reproduccion r WHERE r.usuario.usuarioId = :usuarioId AND r.metadatoYoutube.metadatoId = :metadatoId ORDER BY r.fechaReproduccion DESC")
    List<Reproduccion> findByUsuarioAndMetadato(@Param("usuarioId") Long usuarioId, @Param("metadatoId") Long metadatoId);
}
