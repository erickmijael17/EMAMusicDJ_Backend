package com.emma.emmamusic.domain.reproducir.historial.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/reproducciones")
@RequiredArgsConstructor
@Slf4j
public class ReproduccionController {

    private final ReproduccionService reproduccionService;

    @PostMapping
    public ResponseEntity<ReproduccionDTO> guardarReproduccion(@RequestBody ReproduccionDTO reproduccionDTO) {
        ReproduccionDTO savedReproduccion = reproduccionService.guardarReproduccion(reproduccionDTO);
        return new ResponseEntity<>(savedReproduccion, HttpStatus.CREATED);
    }

    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity<List<ReproduccionDTO>> obtenerHistorialPorUsuario(@PathVariable Long usuarioId) {
        List<ReproduccionDTO> historial = reproduccionService.obtenerHistorialPorUsuario(usuarioId);
        return ResponseEntity.ok(historial);
    }

    @GetMapping("/pista/{pistaId}")
    public ResponseEntity<List<ReproduccionDTO>> obtenerHistorialPorPista(@PathVariable Long pistaId) {
        List<ReproduccionDTO> historial = reproduccionService.obtenerHistorialPorPista(pistaId);
        return ResponseEntity.ok(historial);
    }

    @GetMapping("/video/{videoId}")
    public ResponseEntity<List<ReproduccionDTO>> obtenerHistorialPorVideoId(@PathVariable String videoId) {
        List<ReproduccionDTO> historial = reproduccionService.obtenerHistorialPorVideoId(videoId);
        return ResponseEntity.ok(historial);
    }

    @GetMapping("/usuario/{usuarioId}/fecha")
    public ResponseEntity<List<ReproduccionDTO>> obtenerHistorialPorUsuarioYFecha(
            @PathVariable Long usuarioId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fechaInicio,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fechaFin) {
        
        Timestamp timestampInicio = Timestamp.valueOf(fechaInicio);
        Timestamp timestampFin = Timestamp.valueOf(fechaFin);
        
        List<ReproduccionDTO> historial = reproduccionService.obtenerHistorialPorUsuarioYFecha(
                usuarioId, timestampInicio.toInstant(), timestampFin.toInstant());
        return ResponseEntity.ok(historial);
    }

    @GetMapping("/usuario/{usuarioId}/recientes")
    public ResponseEntity<List<ReproduccionDTO>> obtenerReproduccionesRecientes(@PathVariable Long usuarioId) {
        List<ReproduccionDTO> recientes = reproduccionService.obtenerReproduccionesRecientes(usuarioId);
        return ResponseEntity.ok(recientes);
    }

    @GetMapping("/contar/usuario/{usuarioId}")
    public ResponseEntity<Map<String, Object>> contarReproduccionesPorUsuario(@PathVariable Long usuarioId) {
        long total = reproduccionService.contarReproduccionesPorUsuario(usuarioId);
        return ResponseEntity.ok(Map.of(
                "usuarioId", usuarioId,
                "totalReproducciones", total
        ));
    }

    @GetMapping("/contar/pista/{pistaId}")
    public ResponseEntity<Map<String, Object>> contarReproduccionesPorPista(@PathVariable Long pistaId) {
        long total = reproduccionService.contarReproduccionesPorPista(pistaId);
        return ResponseEntity.ok(Map.of(
                "pistaId", pistaId,
                "totalReproducciones", total
        ));
    }

    @GetMapping("/contar/video/{videoId}")
    public ResponseEntity<Map<String, Object>> contarReproduccionesPorVideoId(@PathVariable String videoId) {
        long total = reproduccionService.contarReproduccionesPorVideoId(videoId);
        return ResponseEntity.ok(Map.of(
                "videoId", videoId,
                "totalReproducciones", total
        ));
    }

    @GetMapping("/estadisticas/usuario/{usuarioId}")
    public ResponseEntity<Map<String, Object>> obtenerEstadisticasUsuario(@PathVariable Long usuarioId) {
        Map<String, Object> estadisticas = reproduccionService.obtenerEstadisticasUsuario(usuarioId);
        return ResponseEntity.ok(estadisticas);
    }

    @GetMapping("/estadisticas/pistas-populares")
    public ResponseEntity<List<Map<String, Object>>> obtenerPistasMasReproducidas() {
        List<Map<String, Object>> pistasPopulares = reproduccionService.obtenerPistasMasReproducidas();
        return ResponseEntity.ok(pistasPopulares);
    }

    @GetMapping("/usuario/{usuarioId}/pista/{pistaId}")
    public ResponseEntity<List<ReproduccionDTO>> obtenerHistorialUsuarioPista(
            @PathVariable Long usuarioId,
            @PathVariable Long pistaId) {
        List<ReproduccionDTO> historial = reproduccionService.obtenerHistorialUsuarioPista(usuarioId, pistaId);
        return ResponseEntity.ok(historial);
    }
}
