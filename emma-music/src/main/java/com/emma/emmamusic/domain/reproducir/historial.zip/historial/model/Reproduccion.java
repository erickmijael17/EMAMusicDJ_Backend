package com.emma.emmamusic.domain.reproducir.historial.model;

import com.emma.emmamusic.domain.auth.model.Usuario;
import com.emma.emmamusic.domain.buscar.model.MetadatoYoutube;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "historial_reproducciones")
public class Reproduccion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "reproduccion_id")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Usuario usuario;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "metadato_id", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private MetadatoYoutube metadatoYoutube;

    @Column(name = "id_video_youtube", length = 50)
    private String idVideoYoutube;

    @CreationTimestamp
    @Column(name = "fecha_reproduccion", updatable = false)
    private java.time.Instant fechaReproduccion;

    @Column(name = "duracion_reproducida_segundos")
    private Integer duracionReproducidaSegundos;

    @Column(name = "porcentaje_completado", precision = 5, scale = 2)
    private BigDecimal porcentajeCompletado;

    @Column(name = "tipo_dispositivo", length = 50)
    private String tipoDispositivo;

    @Column(name = "direccion_ip", length = 50)
    private String direccionIp;

    @Column(name = "pais", length = 100)
    private String pais;

    @Column(name = "ciudad", length = 100)
    private String ciudad;
}
