package com.emma.emmamusic.domain.reproducir.historial.mapper;

import com.emma.emmamusic.domain.auth.model.Usuario;
import com.emma.emmamusic.domain.buscar.model.MetadatoYoutube;
import com.emma.emmamusic.domain.reproducir.historial.dto.ReproduccionDTO;
import com.emma.emmamusic.domain.reproducir.historial.model.Reproduccion;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface ReproduccionMapper {

    @Mapping(source = "usuario.usuarioId", target = "usuarioId")
    @Mapping(source = "metadatoYoutube.metadatoId", target = "metadatoId")
    @Mapping(source = "metadatoYoutube.idVideoYoutube", target = "idVideoYoutube")
    @Mapping(source = "metadatoYoutube.titulo", target = "titulo")
    @Mapping(source = "metadatoYoutube.canal", target = "canal")
    @Mapping(source = "metadatoYoutube.duracionSegundos", target = "duracionSegundos")
    @Mapping(source = "metadatoYoutube.miniaturaUrl", target = "miniaturaUrl")
    ReproduccionDTO toDTO(Reproduccion reproduccion);

    @Mapping(source = "usuarioId", target = "usuario")
    @Mapping(source = "metadatoId", target = "metadatoYoutube")
    @Mapping(target = "fechaReproduccion", ignore = true)
    Reproduccion toEntity(ReproduccionDTO reproduccionDTO);

    default Usuario mapUsuarioFromId(Long id) {
        if (id == null) {
            return null;
        }
        Usuario usuario = new Usuario();
        usuario.setUsuarioId(id);
        return usuario;
    }

    default MetadatoYoutube mapMetadatoFromId(Long id) {
        if (id == null) {
            return null;
        }
        MetadatoYoutube metadato = new MetadatoYoutube();
        metadato.setMetadatoId(id);
        return metadato;
    }
}
